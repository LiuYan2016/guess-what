

export const problems = [
  {
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    pausePosition: 5,
    choices: [
      "Wildlife ranger arrest the hunters",//0
      "Another hunter photo-bomb the scene",//1
      "Another lion chase the hunter for revenge"//2
    ],
    answer: 2
  }
]