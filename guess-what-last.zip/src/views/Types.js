// @flow

/* Define Flow output type here

ex.
export type Output = {
  score: number``
}
*/
export type Output = {
  problemNo: Number,
  selected: String,
  letterIndex: String
}
